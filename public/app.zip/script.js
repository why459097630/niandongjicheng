console.log("App加载成功");

// 模拟一些文物数据
const artifacts = [
  {
    name: "兵马俑",
    dynasty: "秦朝",
    image: "https://example.com/bingmayong.jpg",
    description: "兵马俑是中国古代秦始皇陵的陪葬品，规模宏大，形态逼真。"
  },
  {
    name: "敦煌壁画",
    dynasty: "唐朝",
    image: "https://example.com/dunhuangbihua.jpg",
    description: "敦煌壁画是中国古代艺术宝库之一，内容丰富，形式多样。"
  }
];

// 动态生成文物列表
const artifactList = document.getElementById("artifact-list");
artifacts.forEach((artifact, index) => {
  const listItem = document.createElement("li");
  listItem.textContent = artifact.name;
  listItem.addEventListener("click", () => showDetail(index));
  artifactList.appendChild(listItem);
});

// 显示文物详情页
const showDetail = (index) => {
  const detailPage = document.getElementById("detail-page");
  const detailTitle = document.getElementById("detail-title");
  const detailDynasty = document.getElementById("detail-dynasty");
  const detailImage = document.getElementById("detail-image");
  const detailDescription = document.getElementById("detail-description");
  
  detailTitle.textContent = artifacts[index].name;
  detailDynasty.textContent = artifacts[index].dynasty;
  detailImage.src = artifacts[index].image;
  detailDescription.textContent = artifacts[index].description;
  
  document.getElementById("list-page").style.display = "none";
  detailPage.style.display = "block";
};